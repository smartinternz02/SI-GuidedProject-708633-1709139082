<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>setup and tear down browser</description>
   <name>TestSuiteTC_Cura_Login_001</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>ba13935b-c3ff-4b88-93d9-9be0dc7d9af8</testSuiteGuid>
   <testCaseLink>
      <guid>005a44fa-b638-4763-b4e4-a26987467ae8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_Cura_Login_001</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
