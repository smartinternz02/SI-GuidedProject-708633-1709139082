<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>test suite makeappointment with setup and teardown</description>
   <name>TestSuite_TC_MakeAppointment_002</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>3fc6cb76-61bf-482f-8981-867f190d4275</testSuiteGuid>
   <testCaseLink>
      <guid>9b41c5a4-ab31-49a2-94d8-a2a896f4a3bc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_Cura_MakeAppointment_002</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
