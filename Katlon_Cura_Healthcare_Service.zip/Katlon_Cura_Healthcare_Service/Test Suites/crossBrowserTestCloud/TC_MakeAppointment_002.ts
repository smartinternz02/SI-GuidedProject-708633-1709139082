<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>crossbrowser testing</description>
   <name>TC_MakeAppointment_002</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>543046f4-4fae-4f57-8ccd-abd27b3c85e5</testSuiteGuid>
   <testCaseLink>
      <guid>8faaa3f6-3144-47f5-9a41-4f26a6600da1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_Cura_MakeAppointment_002</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
