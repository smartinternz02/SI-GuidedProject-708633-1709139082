<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>data driven test on Cura HCS Login</description>
   <name>DDT_TC_Cura_Login_001_Excel</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>32992cfd-f464-40bf-a3ed-bb3040b0f217</testSuiteGuid>
   <testCaseLink>
      <guid>e437a0dd-b916-471c-a447-d065ca9c076c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Data Driven Test/DDT_TC_Cura_Login_001</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>cc02b3c2-82be-4a9d-8cd7-de178985e1f1</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Test Data/TestData_Cura_Login</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>cc02b3c2-82be-4a9d-8cd7-de178985e1f1</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>username</value>
         <variableId>db50f3b8-c5aa-49ed-8434-ac7a9aaf30ce</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>cc02b3c2-82be-4a9d-8cd7-de178985e1f1</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>password</value>
         <variableId>b6b284ab-77a7-4ef9-a467-88263a825a02</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
